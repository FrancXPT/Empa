﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Runtime.InteropServices;
using System.Threading;

namespace Empa
{
    class Program
    {
        static bool Initiate(int which)
        {
            /*
                    Order:
                    
                    AI           1
                    Camera       2
                    Motors       3
                    Microphone   4
                    Speaker      5


             */
            bool didSucceed = true;
            bool dosomething = true;
            if (which == 5)
            {
                //  All systems on
                //                     if (success)
                //                     {
                                       didSucceed = true;
                //                     }

            }
            else if (which == 4)
            {
                //  Systems 1-4 on
                //                     if (success)
                //                     {
                                       didSucceed = true;
                //                     }
            }
            else if (which == 3)
            {
                //  Systems 1-3 on
                //                     if (success)
                //                     {
                                       didSucceed = true;
                //                     }
            }
            else if (which == 2)
            {
                //  Systems 1-2 on
                //                     if (success)
                //                     {
                                       didSucceed = true;
                //                     }
            }
            else if (which == 1)
            {
                //  System 1 on
                //                     if (success)
                //                     {
                                       didSucceed = true;
                //                     }

            }
            else if (which == 0)
            {
                //  No action
                dosomething = false;
                didSucceed = true;
            }
            else
            {
                didSucceed = false;
            }
            
                
                    return didSucceed;
               
            
        }
        static void Talk(string say, int speedmax)
        {
            Random rnd = new Random();
            int fun;
            fun = 0;
            int speedmin = speedmax / 2;
            int nums = say.Length;
            for (int i = 0; i < say.Length; i++)
            {
                Char CurrentLetter = say[fun];
                int month = rnd.Next(speedmin, speedmax);  // creates a number between 1 and 12

                Console.Write(say[fun]);
                if (CurrentLetter == '.' || CurrentLetter == '!' || CurrentLetter == '?' || CurrentLetter == ',')
                {
                    System.Threading.Thread.Sleep(month);
                    System.Threading.Thread.Sleep(month * 4);
                }
                System.Threading.Thread.Sleep(month);
                fun++;
            }

        }
        static void Main(string[] args)
        {
            int all = 5;

            int none = 0;


            String logo = @"
                                                                                    
EEEEEEEEEEEEEEEEEEEEEE                                                              
E::::::::::::::::::::E                                                              
E::::::::::::::::::::E                                                              
EE::::::EEEEEEEEE::::E                                                              
  E:::::E       EEEEEE   mmmmmmm    mmmmmmm   ppppp   ppppppppp     aaaaaaaaaaaaa   
  E:::::E              mm:::::::m  m:::::::mm p::::ppp:::::::::p    a::::::::::::a  
  E::::::EEEEEEEEEE   m::::::::::mm::::::::::mp:::::::::::::::::p   aaaaaaaaa:::::a 
  E:::::::::::::::E   m::::::::::::::::::::::mpp::::::ppppp::::::p           a::::a  
  E:::::::::::::::E   m:::::mmm::::::mmm:::::m p:::::p     p:::::p    aaaaaaa:::::a  
  E::::::EEEEEEEEEE   m::::m   m::::m   m::::m p:::::p     p:::::p  aa::::::::::::a  
  E:::::E             m::::m   m::::m   m::::m p:::::p     p:::::p a::::aaaa::::::a    _   _           
  E:::::E       EEEEEEm::::m   m::::m   m::::m p:::::p    p::::::pa::::a    a:::::a   | | | |          
EE::::::EEEEEEEE:::::Em::::m   m::::m   m::::m p:::::ppppp:::::::pa::::a    a:::::a   | |_| |__  _   _ 
E::::::::::::::::::::Em::::m   m::::m   m::::m p::::::::::::::::p a:::::aaaa::::::a   | __| '_ \| | | |
E::::::::::::::::::::Em::::m   m::::m   m::::m p::::::::::::::pp   a::::::::::aa:::a  | |_| | | | |_| |
EEEEEEEEEEEEEEEEEEEEEEmmmmmm   mmmmmm   mmmmmm p::::::pppppppp      aaaaaaaaaa  aaaa   \__|_| |_|\__, |
                                               p:::::p                                            __/ |
                                               p:::::p                                           |___/ 
                                              p:::::::p                              
                                              p:::::::p                              
                                              p:::::::p                              
                                              ppppppppp                              
                                                                                    
An AI with:

Empathy
Sympathy
Generosity
Compassion
Kindness
Love
Care

(ESGCKLC)


";
            
            Console.WriteLine(logo);
            int battery = 100; //                                                                                     <-     Make this equal to Empa's battery.
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("This is the Empa console. It will display info about Empa.");


            bool isSuccess = Initiate(all);

            System.Threading.Thread.Sleep(1000);
            if (isSuccess)
            {
                Console.WriteLine("\n\n[STATUS] Empa ready");
            }
            else
            {
                Console.WriteLine("\n\n[STATUS] Empa initiation failed");
                Console.ReadLine();
                Environment.Exit(0);
            }
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("\n\nEmpa's battery is at approximately " + battery + "%.");
            Console.ReadLine();
        }
    }
}
